function main()
{
 bg([getValue('cx_gzd_CommercialRateFloat') ]); 
 page(['1']); 
 if(getValue('主险条款') != null && getValue('主险条款') != '')  
	{  
		var mixForValue = getValue('主险条款');  
		strs= new Array();  
		strs=getValue('主险条款').split("\n");  
		for (i=0;i<strs.length ;i++ )
		{  
		setValue('主险条款',strs[i]); 
		if(getValue('主险条款') != null && getValue('主险条款') != '')  {  bg([getValue('主险条款')  , getValue('tc_blank')]);  } 
		if(getValue('主险条款') != null && getValue('主险条款') != '')  {  page(['all' , '1']);  } 
		}  
		setValue('主险条款',mixForValue);  
	} 
 if(getValue('附加条款') != null && getValue('附加条款') != '')  {  bg([getValue('附加条款')  , getValue('tc_blank')]);  } 
 if(getValue('附加条款') != null && getValue('附加条款') != '')  {  page(['all' , '1']);  } 
 
 setValue('TOTALPAGE',parseInt(getValue('PAGE')) - 1); 
 exportFun(['TOTALPAGE' , getValue('TOTALPAGE')]); 
}